import { note_obj } from "./main";

export class DataInteraction{

    private title: string;

    constructor(title: string){
        this.title = title;
    }

    addNote(note: note_obj): boolean{
        if(note.body === ""){
            console.log("there's no note body");
            return false;
        }
            
        else if(localStorage.getItem(this.title) !== null){
            console.log("There is already a note with this name");
            return false;
        }
            
        else{
            localStorage.setItem(this.title, JSON.stringify(note));
            return true;
        }
            
    }

    getTitle(): string{
        return this.title;
    }
    search(): string{
        const noteBody = localStorage.getItem(this.title);
        if (noteBody !== null)
            return noteBody;
        else
            return "";
    }
    delete(): string{
        const noteBody = localStorage.getItem(this.title);
        if (noteBody !== null){
            localStorage.removeItem(this.title);
            return `${this.title} was deleted (refresh to see the change)`;
        }    
        else
            return `There's no note named ${this.title}`;
    }
}