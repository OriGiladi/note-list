import { form } from "./main";
import { btnShowForm } from "./main";
import { textInput } from "./main";
import { titleInput } from "./main";
import { do_to_date_Input } from "./main";
import { noteColor } from "./main";
import { DataInteraction } from "./data_interaction";
import { note_obj } from "./main";
import { searchInput } from "./main";
import { searchDiv } from "./main";
import { pDeleted } from "./main";
import { parseDate } from "./main";
import { ListSort } from "./list_sort";
import { divGrid } from "./main";
import { Note } from "./main";
import { gridDiv } from "./main";
import { divContainer } from "./main";
import { confirmationDialog } from "./main";
;
///////////////////////////////////////////////////


// toggles addNote form:
export function toggleFormVisibillity(): void {
    if(form.style.visibility === "visible")
    {
        form.style.visibility = "hidden";
        divContainer.style.visibility = "hidden";
        form.classList.add("gone")
        btnShowForm.textContent = "click to add a new note ";
    }
        
    else
    {
        divContainer.style.visibility = "visible";
        form.style.visibility = "visible";
        btnShowForm.textContent = "hide";
        form.classList.remove("gone")
    }
        
}
// creates new note:
export function createNote(): void{
    const new_note: note_obj = {} as note_obj
    const today: Date = new Date()
    new_note.creation_date = today;
    new_note.body = textInput.value;
    new_note.color = noteColor;
    new_note.do_to_date = new Date(do_to_date_Input.value);
    console.log(new_note.do_to_date)
    const di = new DataInteraction(titleInput.value);
    if(di.addNote(new_note))
        console.log(`title: ${di.getTitle()}, body:  ${di.search()}`)
}

// searches a note

export function searchNote(): void{
    let colorClass: string = "";
    const di = new DataInteraction(searchInput.value)
    if(di.search() !== "")
    {
        pDeleted.textContent = "";
        while (searchDiv.firstChild) {
            searchDiv.removeChild(searchDiv.firstChild);
        }
        searchDiv.style.padding = "20px"
        const di_obj: note_obj = JSON.parse(di.search())
        switch(di_obj.color) {
            case "red":
                if(colorClass === "")
                    searchDiv.classList.add("red");
                else
                    searchDiv.classList.replace(colorClass, 'red');
                colorClass = "red";
                break;
            case "blue":
                if(colorClass === "")
                    searchDiv.classList.add("blue");
                else
                    searchDiv.classList.replace(colorClass, 'blue');
                colorClass = "blue";
                break;
            case "green":
                if(colorClass === "")
                    searchDiv.classList.add("green");
                else
                    searchDiv.classList.replace(colorClass, 'green');
                colorClass = "green";
                break;
            case "yellow":
                if(colorClass === "")
                    searchDiv.classList.add("yellow");
                else
                    searchDiv.classList.replace(colorClass, 'yellow');
                    colorClass = "yellow";
                break;
            default:
                if(colorClass === "")
                    searchDiv.classList.add("white");
                else
                    searchDiv.classList.replace(colorClass, 'white');
                colorClass = 'white';
            }
            
            // if( note.content.do_to_date !== undefined) 
            // {
            //     if( note.content.do_to_date !== null)
            //     {
            //         const lblDoToDate = document.createElement("label");
            //         lblDoToDate.textContent = `Target Date: ${parseDate(note.content.do_to_date)} `;
            //         noteDiv.appendChild(lblDoToDate)
            //     } 
            // }     

            const h3Title = document.createElement("h1");
            h3Title.textContent = ` ${searchInput.value} `;
            searchDiv.appendChild(h3Title)

            const pBody = document.createElement("h3");
            pBody.textContent = ` ${di_obj.body} `;
            searchDiv.appendChild(pBody)
            searchDiv.style.width = '50%'
            
            
              // const lblDate = document.createElement("label");
            // lblDate.textContent = `Creation Date: ${parseDate(note.content.creation_date)} `;
            // noteDiv.appendChild(lblDate)
            const liDate = document.createElement("label");
            liDate.textContent = `Creation Date: ${parseDate(di_obj.creation_date)} `;
            searchDiv.appendChild(liDate)
        
            if(di_obj.do_to_date !== undefined) 
            {
                if(di_obj.do_to_date !== null)
                {
                    const lblDoToDate = document.createElement("label");
                    lblDoToDate.textContent = `Target Date: ${parseDate(di_obj.do_to_date)} `;
                    searchDiv.appendChild(lblDoToDate)
                } 
            }

    }
    else{
        pDeleted.textContent = `There's no note named ${searchInput.value}`;
        while (searchDiv.firstChild) {
            searchDiv.removeChild(searchDiv.firstChild);
        }
        searchDiv.style.border = "none";
    }
}
// deletes a note
export function deleteNote(): void{
    const di = new DataInteraction(searchInput.value)
    pDeleted.textContent = (di.delete())
}


//display all the notes by the sort choise
export function displayNotesFunc(selectedSortWay: string): void{
    while (divGrid.firstChild) {
        divGrid.removeChild(divGrid.firstChild);
    }      
    let notes_list: Note[] = []
    const keys = Object.keys(localStorage);
    keys.forEach((key) => 
    {
        const note :Note = {} as Note
        note.title = key
        note.content = JSON.parse(localStorage.getItem(key)!) 
        notes_list.push(note)
    })
    let displayNotes: Note[] = new ListSort(notes_list).SortByDate()
    if(selectedSortWay === "alphabet")
        displayNotes = new ListSort(notes_list).SortByAlphabet()
    else if(selectedSortWay === "do_to_date")
        displayNotes = new ListSort(notes_list).SortByDueToDate()
    displayNotes.forEach(note => {
        const noteDiv = document.createElement('div')
        noteDiv.classList.add('note')
        switch(note.content.color) {
            case "red":
                noteDiv.classList.add("red");
                break;
            case "blue":
                noteDiv.classList.add("blue");
                break;
            case "green":
                noteDiv.classList.add("green");
                break;
            case "yellow":
                noteDiv.classList.add("yellow");
                break;
            default:
                noteDiv.classList.add("white");
        }
        gridDiv.appendChild(noteDiv);

        const value = note.content.body;
        const h3Title = document.createElement("h1");
        h3Title.textContent = ` ${note.title} `;
        noteDiv.appendChild(h3Title)

        const pBody = document.createElement("h3");
        pBody.textContent = `${value} `;
        noteDiv.appendChild(pBody)
    
        const lblDate = document.createElement("label");
        lblDate.textContent = `Creation Date: ${parseDate(note.content.creation_date)} `;
        noteDiv.appendChild(lblDate)
        if( note.content.do_to_date !== undefined) 
        {
            if( note.content.do_to_date !== null)
            {
                const lblDoToDate = document.createElement("label");
                lblDoToDate.textContent = `Target Date: ${parseDate(note.content.do_to_date)} `;
                noteDiv.appendChild(lblDoToDate)
            } 
        }     
    })
}

export function showConfirmationDialog() {
    confirmationDialog.style.display = 'block';
}

export function hideConfirmationDialog() {
    confirmationDialog.style.display = 'none';
}

export function clearNote() {
    localStorage.clear();
}