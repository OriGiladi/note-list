import { createNote } from "./dom_interaction";
import { toggleFormVisibillity } from "./dom_interaction";
import { searchNote } from "./dom_interaction";
import { clearNote } from "./dom_interaction";
import { deleteNote } from "./dom_interaction";
import { displayNotesFunc } from "./dom_interaction";
import { hideConfirmationDialog } from "./dom_interaction";
import { showConfirmationDialog } from "./dom_interaction";
//////////////////////////////////////////////////////////////////
const showForm: HTMLButtonElement = document.getElementById('showForm') as HTMLButtonElement;

export const form: HTMLFormElement = document.getElementById('createNote') as HTMLFormElement;

export const titleInput: HTMLInputElement = document.getElementById('titleInput') as HTMLInputElement;

export const textInput: HTMLTextAreaElement = document.getElementById('textInput') as HTMLTextAreaElement;

export const searchInput: HTMLInputElement = document.getElementById('txtSearch') as HTMLInputElement;

const btnSearch: HTMLButtonElement = document.getElementById('search') as HTMLButtonElement;

const btnDelete: HTMLButtonElement = document.getElementById('delete') as HTMLButtonElement;

export const btnClear: HTMLButtonElement= document.getElementById('clear') as HTMLButtonElement;
export const confirmationDialog: HTMLDivElement= document.querySelector('.confirmation-dialog') as HTMLDivElement;
export const confirmYesBtn: HTMLButtonElement = document.getElementById('confirmYes') as HTMLButtonElement;
export const confirmNoBtn: HTMLButtonElement = document.getElementById('confirmNo') as HTMLButtonElement;

const sortDropDown: HTMLSelectElement = document.getElementById('sordDD') as HTMLSelectElement;

const btnRed: HTMLButtonElement = document.getElementById('red') as HTMLButtonElement;
const btnBlue: HTMLButtonElement = document.getElementById('blue') as HTMLButtonElement;
const btnGreen: HTMLButtonElement = document.getElementById('green') as HTMLButtonElement;
const btnYellow: HTMLButtonElement = document.getElementById('yellow') as HTMLButtonElement;
const btnWhite: HTMLButtonElement = document.getElementById('white') as HTMLButtonElement;

export const pDeleted: HTMLParagraphElement = document.getElementById('p_deleted') as HTMLParagraphElement;

export const do_to_date_Input: HTMLInputElement = document.getElementById('do_to_date') as HTMLInputElement;

export let divGrid: HTMLDivElement = document.getElementById('grid') as HTMLDivElement;

type color = "red" | "blue" | "green" | "yellow" | "white";
export let noteColor: color = "white";

export const btnShowForm: HTMLButtonElement = document.getElementById('showForm') as HTMLButtonElement;

export const searchDiv: HTMLDivElement = document.getElementById('searched') as HTMLDivElement;

export const gridDiv: HTMLDivElement = document.getElementById('grid') as HTMLDivElement;

export const  divContainer: HTMLDivElement = document.getElementById('form-container') as HTMLDivElement;

/////////////////////////////////////////////////////////////////////////

export interface Note{
    title: string;
    content: note_obj
}


export type note_obj = {
    body: string,
    creation_date: Date,
    do_to_date?: Date,
    color: color
}
export function parseDate (today: Date) : string{
    const dateObj = new Date(today)
    return `${dateObj.getDate()}/${dateObj.getMonth() + 1}/${dateObj.getFullYear()}`;
}

/////////////////////////////////////////////////////////////////////
showForm.addEventListener("click", () =>{
    toggleFormVisibillity();
})

btnSearch.addEventListener("click", () =>{
    searchNote();
})

btnDelete.addEventListener("click", () =>{
    deleteNote();
})


form.addEventListener("submit", (e) => {
    e.preventDefault();
    createNote();
})

sortDropDown.addEventListener("change", () => {
    const selectedSortWay: string = sortDropDown.value;
    displayNotesFunc(selectedSortWay);
})

btnRed.addEventListener("click", () =>{noteColor = "red"});
btnBlue.addEventListener("click", () =>{noteColor = "blue"});
btnGreen.addEventListener("click", () =>{noteColor = "green"});
btnYellow.addEventListener("click", () =>{noteColor = "yellow"});
btnWhite.addEventListener("click", () =>{noteColor = "white"});
displayNotesFunc("date");

do_to_date_Input.addEventListener("change",() =>{
    console.log(new Date(do_to_date_Input.value) )
})


btnClear.addEventListener('click', () => {
    showConfirmationDialog();
});

confirmYesBtn.addEventListener('click', () => {
    clearNote();
    hideConfirmationDialog();
});

confirmNoBtn.addEventListener('click', () => {
    hideConfirmationDialog();
});

